﻿using System.ComponentModel.DataAnnotations;

namespace WebAuthentication_UsingSessing.Models
{
    public class LoginSignUpViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        [Display(Name = "Remember Me")]
        public bool IsRemember { get; set; }
    }
}
