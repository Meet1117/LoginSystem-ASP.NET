﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebAuthentication_UsingSessing.db;
using WebAuthentication_UsingSessing.Models;

namespace WebAuthentication_UsingSessing.Controllers
{
    public class AdminPanelController : Controller
    {
        private readonly DB mydb;

        public AdminPanelController(DB mydb)
        {
            this.mydb = mydb;
        }

        [Authorize]
        public IActionResult GetData()
        {
            IEnumerable<Users> xData = mydb.Users; 
            return View(xData);
        }


    }
}
