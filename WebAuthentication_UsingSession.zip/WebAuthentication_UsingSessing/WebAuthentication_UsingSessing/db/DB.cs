﻿using Microsoft.EntityFrameworkCore;
using WebAuthentication_UsingSessing.Models;

namespace WebAuthentication_UsingSessing.db
{
    public class DB : DbContext
    {
        public DB() { }
        public DB(DbContextOptions<DB> options) : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
    }
}
